package org.strutted.htb;

import com.opensymphony.xwork2.ActionSupport;

public class HowAction extends ActionSupport {

    @Override
    public String execute() {
        return SUCCESS;
    }
}